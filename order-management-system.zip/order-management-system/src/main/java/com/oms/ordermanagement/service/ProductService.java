package com.oms.ordermanagement.service;

import com.oms.ordermanagement.dto.ProductDTO;
import com.oms.ordermanagement.entity.Product;
import com.oms.ordermanagement.exception.ResourceNotFoundException;
import com.oms.ordermanagement.repository.ProductRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductService {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    // ===============================
    // CREATE PRODUCT
    // ===============================
    public ProductDTO createProduct(ProductDTO productDTO) {
        Product product = mapToEntity(productDTO);
        Product savedProduct = productRepository.save(product);
        return mapToDTO(savedProduct);
    }

    // ===============================
    // GET PRODUCT BY ID
    // ===============================
    public ProductDTO getProductById(Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Product not found with id " + id));
        return mapToDTO(product);
    }

    // ===============================
    // GET ALL PRODUCTS (SORTING)
    // ===============================
    public List<ProductDTO> getAllProducts(String sortBy) {
        return productRepository.findAll(Sort.by(sortBy))
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    // ===============================
    // UPDATE PRODUCT
    // ===============================
    public ProductDTO updateProduct(Long id, ProductDTO updatedProductDTO) {
        Product product = productRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Product not found with id " + id));

        product.setName(updatedProductDTO.getName());
        product.setPrice(updatedProductDTO.getPrice());
        product.setStock(updatedProductDTO.getStock());

        Product updatedProduct = productRepository.save(product);
        return mapToDTO(updatedProduct);
    }

    // ===============================
    // DELETE PRODUCT
    // ===============================
    public void deleteProduct(Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Product not found with id " + id));
        productRepository.delete(product);
    }

    // ===============================
    // MAPPER METHODS
    // ===============================
    private ProductDTO mapToDTO(Product product) {
        return new ProductDTO(
                product.getId(),
                product.getName(),
                product.getPrice(),
                product.getStock()
        );
    }

    private Product mapToEntity(ProductDTO productDTO) {
        Product product = new Product();
        product.setName(productDTO.getName());
        product.setPrice(productDTO.getPrice());
        product.setStock(productDTO.getStock());
        return product;
    }

    // Used internally by other services (OrderService)
    public Product getProductEntityById(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Product not found with id " + id));
    }

    public List<ProductDTO> getLowStockProducts(Integer threshold) {
        return productRepository.findByStockLessThanEqual(threshold)
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }


}
