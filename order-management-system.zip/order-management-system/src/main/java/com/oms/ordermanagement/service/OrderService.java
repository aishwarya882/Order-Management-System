package com.oms.ordermanagement.service;

import com.oms.ordermanagement.dto.*;
import com.oms.ordermanagement.entity.*;
import com.oms.ordermanagement.exception.BusinessException;
import com.oms.ordermanagement.exception.ResourceNotFoundException;
import com.oms.ordermanagement.repository.CustomerRepository;
import com.oms.ordermanagement.repository.OrderItemRepository;
import com.oms.ordermanagement.repository.OrderRepository;
import com.oms.ordermanagement.repository.ProductRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final CustomerRepository customerRepository;
    private final ProductRepository productRepository;

    public OrderService(OrderRepository orderRepository,
                        OrderItemRepository orderItemRepository,
                        CustomerRepository customerRepository,
                        ProductRepository productRepository) {
        this.orderRepository = orderRepository;
        this.orderItemRepository = orderItemRepository;
        this.customerRepository = customerRepository;
        this.productRepository = productRepository;
    }

    // ===============================
    // GET ORDERS BY CUSTOMER ID
    // ===============================
    public List<OrderDTO> getOrdersByCustomerId(Long customerId) {
        customerRepository.findById(customerId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Customer not found with id " + customerId));

        return orderRepository.findByCustomerId(customerId)
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    // ===============================
    // GET ORDER ITEMS BY CUSTOMER ID
    // ===============================
    public List<OrderItemDTO> getOrderItemsByCustomerId(Long customerId) {
        customerRepository.findById(customerId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Customer not found with id " + customerId));

        return orderItemRepository.findByOrderCustomerId(customerId)
                .stream()
                .map(this::mapOrderItemToDTO)
                .collect(Collectors.toList());
    }

    // ===============================
    // PLACE ORDER
    // ===============================
    @Transactional
    public OrderDTO placeOrder(OrderRequest request) {

        Customer customer = customerRepository.findById(request.getCustomerId())
                .orElseThrow(() ->
                        new ResourceNotFoundException("Customer not found with id " + request.getCustomerId()));

        Order order = new Order();
        order.setCustomer(customer);
        order.setStatus(OrderStatus.CREATED);

        List<OrderItem> orderItems = new ArrayList<>();
        double totalAmount = 0;

        for (OrderItemRequest itemRequest : request.getItems()) {

            Product product = productRepository.findById(itemRequest.getProductId())
                    .orElseThrow(() ->
                            new ResourceNotFoundException("Product not found with id " + itemRequest.getProductId()));

            if (product.getStock() < itemRequest.getQuantity()) {
                throw new BusinessException("Insufficient stock for product: " + product.getName());
            }

            product.setStock(product.getStock() - itemRequest.getQuantity());

            OrderItem orderItem = new OrderItem();
            orderItem.setOrder(order);
            orderItem.setProduct(product);
            orderItem.setQuantity(itemRequest.getQuantity());
            orderItem.setPrice(product.getPrice());

            totalAmount += product.getPrice() * itemRequest.getQuantity();
            orderItems.add(orderItem);
        }

        order.setItems(orderItems);
        order.setTotalAmount(totalAmount);

        Order savedOrder = orderRepository.save(order);
        return mapToDTO(savedOrder);
    }

    // ===============================
    // GET ORDER BY ID
    // ===============================
    public OrderDTO getOrderById(Long id) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Order not found with id " + id));
        return mapToDTO(order);
    }

    // ===============================
    // UPDATE ORDER STATUS
    // ===============================
    @Transactional
    public OrderDTO updateOrderStatus(Long orderId, OrderStatus newStatus) {

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Order not found with id " + orderId));

        if (order.getStatus() == OrderStatus.CANCELLED &&
                newStatus == OrderStatus.CONFIRMED) {
            throw new BusinessException("Cancelled order cannot be confirmed");
        }

        order.setStatus(newStatus);
        Order updatedOrder = orderRepository.save(order);
        return mapToDTO(updatedOrder);
    }

    // ===============================
    // MAPPER METHODS
    // ===============================
    private OrderDTO mapToDTO(Order order) {
        List<OrderItemDTO> itemDTOs = order.getItems()
                .stream()
                .map(this::mapOrderItemToDTO)
                .collect(Collectors.toList());

        return new OrderDTO(
                order.getId(),
                order.getCustomer().getId(),
                order.getOrderDate(),
                order.getTotalAmount(),
                order.getStatus().name(),
                itemDTOs
        );
    }

    private OrderItemDTO mapOrderItemToDTO(OrderItem orderItem) {
        return new OrderItemDTO(
                orderItem.getId(),
                orderItem.getProduct().getId(),
                orderItem.getProduct().getName(),
                orderItem.getQuantity(),
                orderItem.getPrice()
        );
    }

    public OrderDTO cancelOrder(Long orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with id " + orderId));

        // Only allow cancel if not already cancelled
        if (order.getStatus() == OrderStatus.CANCELLED) {
            throw new IllegalStateException("Order is already cancelled.");
        }

        // Restore stock for each item
        for (OrderItem item : order.getItems()) {
            Product product = item.getProduct();
            product.setStock(product.getStock() + item.getQuantity());
            productRepository.save(product);
        }

        // Update order status
        order.setStatus(OrderStatus.CANCELLED);
        Order updatedOrder = orderRepository.save(order);

        return mapToDTO(updatedOrder);
    }



}
