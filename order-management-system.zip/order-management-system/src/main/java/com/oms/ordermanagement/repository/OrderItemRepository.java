package com.oms.ordermanagement.repository;

import com.oms.ordermanagement.entity.OrderItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OrderItemRepository extends JpaRepository<OrderItem, Long> {


    List<OrderItem> findByOrderCustomerId(Long customerId);
}
