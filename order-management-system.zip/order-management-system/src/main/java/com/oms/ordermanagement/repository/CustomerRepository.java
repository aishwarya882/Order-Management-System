package com.oms.ordermanagement.repository;

import com.oms.ordermanagement.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CustomerRepository extends JpaRepository<Customer, Long> {

    // Derived query method
    Optional<Customer> findByEmail(String email);

    boolean existsByEmail(String email);
}
