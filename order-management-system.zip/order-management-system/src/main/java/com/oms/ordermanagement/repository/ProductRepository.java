package com.oms.ordermanagement.repository;
import java.util.List;


import com.oms.ordermanagement.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findByStockLessThanEqual(Integer stock);
}
