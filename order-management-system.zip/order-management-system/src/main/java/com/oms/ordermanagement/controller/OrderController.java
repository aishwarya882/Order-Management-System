package com.oms.ordermanagement.controller;

import com.oms.ordermanagement.dto.OrderDTO;
import com.oms.ordermanagement.dto.OrderRequest;
import com.oms.ordermanagement.dto.OrderStatusRequest;
import com.oms.ordermanagement.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    // ===============================
    // PLACE ORDER
    // ===============================
    @PostMapping
    public ResponseEntity<OrderDTO> placeOrder(
            @Valid @RequestBody OrderRequest request) {

        OrderDTO order = orderService.placeOrder(request);
        return new ResponseEntity<>(order, HttpStatus.CREATED);
    }

    // ===============================
    // GET ORDER BY ID (QUERY PARAM)
    // ===============================
    @GetMapping("/by-id")
    public ResponseEntity<OrderDTO> getOrderById(
            @RequestParam Long orderId) {

        return ResponseEntity.ok(orderService.getOrderById(orderId));
    }

    // ===============================
    // UPDATE ORDER STATUS (QUERY PARAM)
    // ===============================
    @PutMapping("/status")
    public ResponseEntity<OrderDTO> updateOrderStatus(
            @RequestParam Long orderId,
            @Valid @RequestBody OrderStatusRequest request) {

        OrderDTO updatedOrder =
                orderService.updateOrderStatus(orderId, request.getStatus());

        return ResponseEntity.ok(updatedOrder);
    }

    // ===============================
// CANCEL ORDER
// ===============================
    @PutMapping("/cancel")
    public ResponseEntity<OrderDTO> cancelOrder(
            @RequestParam Long orderId) {

        OrderDTO cancelledOrder = orderService.cancelOrder(orderId);
        return ResponseEntity.ok(cancelledOrder);
    }

}
