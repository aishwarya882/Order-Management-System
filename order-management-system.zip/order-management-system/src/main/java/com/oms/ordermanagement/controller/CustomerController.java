package com.oms.ordermanagement.controller;

import com.oms.ordermanagement.dto.CustomerDTO;
import com.oms.ordermanagement.entity.Order;
import com.oms.ordermanagement.entity.OrderItem;
import com.oms.ordermanagement.service.CustomerService;
import com.oms.ordermanagement.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.oms.ordermanagement.dto.OrderDTO;
import com.oms.ordermanagement.dto.OrderItemDTO;


import java.util.List;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    private final CustomerService customerService;
    private final OrderService orderService;

    public CustomerController(CustomerService customerService,
                              OrderService orderService) {
        this.customerService = customerService;
        this.orderService = orderService;
    }

    // ===============================
    // CREATE CUSTOMER
    // ===============================
    @PostMapping
    public ResponseEntity<CustomerDTO> createCustomer(
            @Valid @RequestBody CustomerDTO customerDTO) {

        CustomerDTO savedCustomer = customerService.createCustomer(customerDTO);
        return new ResponseEntity<>(savedCustomer, HttpStatus.CREATED);
    }

    // ===============================
    // GET CUSTOMER BY ID (QUERY PARAM)
    // ===============================
    @GetMapping("/by-id")
    public ResponseEntity<CustomerDTO> getCustomerById(
            @RequestParam Long customerId) {

        CustomerDTO customer = customerService.getCustomerById(customerId);
        return ResponseEntity.ok(customer);
    }

    // ===============================
    // GET ALL CUSTOMERS
    // ===============================
    @GetMapping
    public ResponseEntity<List<CustomerDTO>> getAllCustomers() {
        return ResponseEntity.ok(customerService.getAllCustomers());
    }

    // ===============================
    // UPDATE CUSTOMER (QUERY PARAM)
    // ===============================
    @PutMapping
    public ResponseEntity<CustomerDTO> updateCustomer(
            @RequestParam Long customerId,
            @Valid @RequestBody CustomerDTO customerDTO) {

        CustomerDTO updatedCustomer =
                customerService.updateCustomer(customerId, customerDTO);

        return ResponseEntity.ok(updatedCustomer);
    }

    // ===============================
    // DELETE CUSTOMER (QUERY PARAM)
    // ===============================
    @DeleteMapping
    public ResponseEntity<Void> deleteCustomer(
            @RequestParam Long customerId) {

        customerService.deleteCustomer(customerId);
        return ResponseEntity.noContent().build();
    }

    // ===============================
    // GET ORDERS BY CUSTOMER ID
    // ===============================
    @GetMapping("/orders")
    public ResponseEntity<List<OrderDTO>> getOrdersByCustomer(
            @RequestParam Long customerId) {

        return ResponseEntity.ok(
                orderService.getOrdersByCustomerId(customerId));
    }

    @GetMapping("/orders/items")
    public ResponseEntity<List<OrderItemDTO>> getOrderItemsByCustomer(
            @RequestParam Long customerId) {

        return ResponseEntity.ok(
                orderService.getOrderItemsByCustomerId(customerId));
    }

}
