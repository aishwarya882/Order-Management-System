package com.oms.ordermanagement.controller;

import com.oms.ordermanagement.dto.ProductDTO;
import com.oms.ordermanagement.service.ProductService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    // ===============================
    // CREATE PRODUCT
    // ===============================
    @PostMapping
    public ProductDTO createProduct(
            @Valid @RequestBody ProductDTO productDTO) {

        return productService.createProduct(productDTO);
    }

    // ===============================
    // GET PRODUCT BY ID (QUERY PARAM)
    // ===============================
    @GetMapping("/by-id")
    public ProductDTO getProductById(
            @RequestParam Long productId) {

        return productService.getProductById(productId);
    }

    // ===============================
    // GET ALL PRODUCTS (SORTING)
    // ===============================
    @GetMapping
    public List<ProductDTO> getAllProducts(
            @RequestParam(defaultValue = "id") String sortBy) {

        return productService.getAllProducts(sortBy);
    }

    // ===============================
    // UPDATE PRODUCT (QUERY PARAM)
    // ===============================
    @PutMapping
    public ProductDTO updateProduct(
            @RequestParam Long productId,
            @Valid @RequestBody ProductDTO productDTO) {

        return productService.updateProduct(productId, productDTO);
    }

    // ===============================
    // DELETE PRODUCT (QUERY PARAM)
    // ===============================
    @DeleteMapping
    public void deleteProduct(
            @RequestParam Long productId) {

        productService.deleteProduct(productId);
    }

    // ===============================
// GET LOW STOCK PRODUCTS
// ===============================
    @GetMapping("/low-stock")
    public List<ProductDTO> getLowStockProducts(
            @RequestParam(defaultValue = "5") Integer threshold) {

        return productService.getLowStockProducts(threshold);
    }

}
