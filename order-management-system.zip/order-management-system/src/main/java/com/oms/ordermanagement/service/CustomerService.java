package com.oms.ordermanagement.service;

import com.oms.ordermanagement.dto.CustomerDTO;
import com.oms.ordermanagement.entity.Customer;
import com.oms.ordermanagement.repository.CustomerRepository;
import org.springframework.stereotype.Service;
import com.oms.ordermanagement.exception.BadRequestException;
import com.oms.ordermanagement.exception.ResourceNotFoundException;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CustomerService {

    private final CustomerRepository customerRepository;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    // ===============================
    // CREATE CUSTOMER
    // ===============================
    public CustomerDTO createCustomer(CustomerDTO customerDTO) {
        if (customerRepository.existsByEmail(customerDTO.getEmail())) {
            throw new BadRequestException("Email already exists");
        }

        Customer customer = mapToEntity(customerDTO);
        Customer savedCustomer = customerRepository.save(customer);
        return mapToDTO(savedCustomer);
    }

    // ===============================
    // GET CUSTOMER BY ID
    // ===============================
    public CustomerDTO getCustomerById(Long id) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Customer not found with id " + id));
        return mapToDTO(customer);
    }

    // ===============================
    // GET ALL CUSTOMERS
    // ===============================
    public List<CustomerDTO> getAllCustomers() {
        return customerRepository.findAll()
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    // ===============================
    // UPDATE CUSTOMER
    // ===============================
    public CustomerDTO updateCustomer(Long id, CustomerDTO updatedCustomerDTO) {
        Customer existingCustomer = customerRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Customer not found with id " + id));

        existingCustomer.setName(updatedCustomerDTO.getName());
        existingCustomer.setEmail(updatedCustomerDTO.getEmail());

        Customer updatedCustomer = customerRepository.save(existingCustomer);
        return mapToDTO(updatedCustomer);
    }

    // ===============================
    // DELETE CUSTOMER
    // ===============================
    public void deleteCustomer(Long id) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Customer not found with id " + id));
        customerRepository.delete(customer);
    }

    // ===============================
    // MAPPER METHODS
    // ===============================
    private CustomerDTO mapToDTO(Customer customer) {
        return new CustomerDTO(
                customer.getId(),
                customer.getName(),
                customer.getEmail()
        );
    }

    private Customer mapToEntity(CustomerDTO customerDTO) {
        Customer customer = new Customer();
        customer.setName(customerDTO.getName());
        customer.setEmail(customerDTO.getEmail());
        return customer;
    }

    // Used internally by other services (OrderService)
    public Customer getCustomerEntityById(Long id) {
        return customerRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Customer not found with id " + id));
    }

}
