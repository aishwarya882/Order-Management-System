package com.oms.ordermanagement.entity;

public enum OrderStatus {
    CREATED,
    CONFIRMED,
    CANCELLED
}
